import pandas as pd
import numpy as np
import pickle
import lightgbm as lgb
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from datetime import datetime
from sklearn.cluster import KMeans
from predict import rebase, select_max

def generate_pkl_files():
	#import file
	df = pd.read_excel("Online Retail.xlsx")
	
	#remove empty customer
	df = df[~df['CustomerID'].isna()]
	df = df.reset_index()
	
	#add two columns
	df['TotalPrice'] = df['Quantity'] * df['UnitPrice']
	df['TotalPrice2'] = df['Quantity'] * df['UnitPrice']
	
	#one hot encoding
	encoder = CountVectorizer()
	df_encoded = encoder.fit_transform(df['Description'])
	freq = sum(df_encoded.toarray())
	n_occurences = 500
	df_encoded = pd.DataFrame(df_encoded.toarray()[:, freq>n_occurences])	#remove unused words
	df_encoded.columns = np.asarray(encoder.get_feature_names())[freq>500]
	to_delete = ['10', '11', '12', '20', '24', '36', '3d', 					#remove useless words
				 '50', '60', '72', 'am', 'and', 'black', 
				 'blue', 'deluxe', 'for', 'giant', 'green', 
				 'grey', 'grow', 'happy', 'hot', 'in', 'it', 
				 'making', 'medium', 'memo', 'mini', 'mint', 
				 'multi', 'new', 'night', 'no', 'of', 'of4', 
				 'on', 'one', 'or', 'orange', 'over', 'pink', 
				 'please', 'red',  'rose', 'size', 'small', 'so', 
				 'soft', 'sweet', 'tall', 'the', 'tidy', 'tier', 
				 'tonic', 'top', 'traditional', 'triple', 'union', 
				 'up', 'welcome', 'white', 'word', 'world', 'yellow', 
				 'you', 'your']
	df_encoded = df_encoded.drop(columns=to_delete)
	columns_to_keep = list(df_encoded.columns)
	
	#merge with initial dataframe
	df = pd.concat([df, df_encoded], axis=1, join='inner')
	
	#DaysFromLastOrder
	NOW = datetime(2019,1,1)
	df_reduced = df.loc[:, ['CustomerID', 'InvoiceNo', 'InvoiceDate']] \
					.drop_duplicates() \
					.sort_values(['CustomerID', 'InvoiceDate'])
	
	#when no value for DaysFromLastOrder
	penality = 1000
	
	#calculate the number of days between two orders
	#by shifting the dataframes
	cond = df_reduced.CustomerID != df_reduced.CustomerID.shift(1)
	df_reduced['DaysFromLastOrder'] = (df_reduced.InvoiceDate - df_reduced.InvoiceDate.shift(1))
	df_reduced['DaysFromLastOrder'] = df_reduced['DaysFromLastOrder'].apply(lambda x: x.days)
	df_reduced.loc[cond, 'DaysFromLastOrder'] = penality
	
	#merge with main dataframe
	df = pd.merge(df, 
				  df_reduced.loc[:, ['CustomerID', 'InvoiceNo', 'DaysFromLastOrder']], 
				  on=['CustomerID', 'InvoiceNo'])
	
	#RFML Table
	rfmTable = df.groupby('CustomerID').agg({'InvoiceDate': lambda x: (NOW - x.max()).days, 
                                         'InvoiceNo': lambda x: len(x.drop_duplicates()),
                                         'TotalPrice': lambda x: x.sum(), 
                                         'TotalPrice2': lambda x: x.mean(), 
                                         'DaysFromLastOrder': lambda x: x[x > 0].mean()})
	rfmTable['InvoiceDate'] = rfmTable['InvoiceDate'].astype(int)
	rfmTable.rename(columns={'InvoiceDate': 'recency', 
                         'InvoiceNo': 'frequency', 
                         'TotalPrice': 'monetary_value',
                         'TotalPrice2': 'average_value',
                         'DaysFromLastOrder': 'average_days_between_orders'}, inplace=True)
	
	#Aggregate the sum of words occurences from One Hot Encoding
	df_ohe = pd.concat([df['CustomerID'], df.iloc[:, 11:-1]], axis=1, join='inner')
	df_ohe = df_ohe.groupby('CustomerID').agg(np.sum)
	
	#Merge with RFM table
	rfmTable = pd.merge(rfmTable, df_ohe, on='CustomerID')
	
	#remove null monetary value
	rfmTable = rfmTable[rfmTable['monetary_value'] != 0]
	rfmTable = rfmTable.reset_index()
	
	#PCA (only on One Hot Encoding)
	pca = PCA(n_components=6)
	pca.fit(rfmTable.iloc[:,6:].values)
	reduced_matrix = pca.transform(rfmTable.iloc[:,6:].values)
	df_reduced = pd.concat([rfmTable.iloc[:,0:6], 
							pd.DataFrame(reduced_matrix)], 
						   axis=1, 
						   join='inner')
	
	#Scale data (excluding CustomerID)
	scaler = StandardScaler()
	df_reduced_norm = pd.DataFrame(scaler.fit_transform(df_reduced.iloc[:, 1:]))
	df_reduced_norm.columns = df_reduced.columns[1:]
	
	#Performs classification
	km = KMeans(n_clusters=7)
	km.fit(df_reduced_norm.values)
	df_reduced['interest_cluster'] = km.predict(df_reduced_norm.values)
	rfmTable['interest_cluster'] = km.predict(df_reduced_norm.values)
	
	#Detect the clusters of interest
	cnt = pd.DataFrame(
			pd.DataFrame(
				df_reduced.loc[:, ['CustomerID', 'interest_cluster']] \
							.groupby('interest_cluster') \
							.agg(['count'])
				).values
			)
	cluster_of_interest = []
	while len(cluster_of_interest) < 4:
		cluster_of_interest.append(
        	list(cnt.loc[list(set(list(cnt.index)) - set(cluster_of_interest)),:].idxmax())[0]
    	)
	
	cluster_of_interest.sort()
	grouped = rfmTable.groupby('interest_cluster').agg(np.mean)
	huge_monetary_cluster = list(grouped.loc[grouped['monetary_value'] > 100000].index)[0]
	weekly_big_buyers_cluster = list(grouped.loc[
									(grouped['monetary_value'] > 30000) & 
									(grouped['average_days_between_orders'] > 6),:].index)[0]
	dayly_big_buyers_cluster = list(grouped.loc[
									(grouped['monetary_value'] > 30000) & 
									(grouped['average_days_between_orders'] < 6),:].index)[0]
	#Train LGBM model
	X = df_reduced_norm.iloc[[True if x in cluster_of_interest 
						 	else False for x in df_reduced['interest_cluster']], :].values
	
	y = df_reduced.iloc[[True if x in cluster_of_interest 
						 	else False for x in df_reduced['interest_cluster']], -1:]
	
	cID = df_reduced.loc[[True if x in cluster_of_interest 
						 	else False for x in df_reduced['interest_cluster']], ['CustomerID']]
	
	f = lambda row: rebase(row[0], cluster_of_interest)
	y = y.apply(f, axis=1).values
	
	d_train = lgb.Dataset(X, label=y.ravel())
	params = {}
	params['objective'] = 'multiclass'
	params['num_class'] = len(cluster_of_interest)
	params['metric'] = 'multi_logloss'
	params['num_leaves'] = 10
	params['max_depth'] = 3
	clf = lgb.train(params, d_train, 100)
	y_pred = pd.DataFrame(clf.predict(X))
	f = lambda row: select_max(row[:], cluster_of_interest)
	y_pred = pd.DataFrame(y_pred.apply(f, axis=1))
	y_pred['CustomerID'] = pd.DataFrame(cID.iloc[:,0].values)
	
	#We can now export all pickles
	output = open('encoder.pkl', 'wb')
	pickle.dump(encoder, output)
	output.close()
	
	output = open('pca.pkl', 'wb')
	pickle.dump(pca, output)
	output.close()
	
	output = open('scaler.pkl', 'wb')
	pickle.dump(scaler, output)
	output.close()
	
	output = open('columns_to_keep.pkl', 'wb')
	pickle.dump(columns_to_keep, output)
	output.close()
	
	output = open('cluster_of_interest.pkl', 'wb')
	pickle.dump(cluster_of_interest, output)
	output.close()
	
	output = open('huge_monetary_cluster.pkl', 'wb')
	pickle.dump(huge_monetary_cluster, output)
	output.close()
	
	output = open('weekly_big_buyers_cluster.pkl', 'wb')
	pickle.dump(weekly_big_buyers_cluster, output)
	output.close()
	
	output = open('dayly_big_buyers_cluster.pkl', 'wb')
	pickle.dump(dayly_big_buyers_cluster, output)
	output.close()
	
	output = open('predictor.pkl', 'wb')
	pickle.dump(clf, output)
	output.close()

	return X, y_pred