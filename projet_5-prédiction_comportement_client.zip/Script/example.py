# This file aims to show how to use .py files
# to predict user's cluster.
from preparation_script import generate_pkl_files
from predict import predict
import pandas as pd

# First we need to create all pickle files 
# containing used objects after fitting
# to increase prediction speed.
X1, y_pred1 = generate_pkl_files()
print('Cluster after training for CustomerID 17850:' + str(y_pred1.loc[y_pred1['CustomerID']==17850,0].values[0]))

# Now we can import all time series.
df = pd.read_excel("Online Retail.xlsx")

# We select one customer.
df = df[df['CustomerID']==17850]

# And now prediction.
X2, y_pred2 = predict(df)
print('Cluster after prediction for CustomerID 17850: ' + str(y_pred2[0]))
