import pandas as pd
import numpy as np
import pickle
import lightgbm as lgb
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from datetime import datetime

def rebase(i, cluster_of_interest):
    if i == cluster_of_interest[0]:
        return 0
    elif i == cluster_of_interest[1]:
        return 1
    elif i == cluster_of_interest[2]:
        return 2
    elif i == cluster_of_interest[3]:
        return 3
	
def select_max(m, cluster_of_interest):
    if m[0] == max(m):
        return cluster_of_interest[0]
    if m[1] == max(m):
        return cluster_of_interest[1]
    if m[2] == max(m):
        return cluster_of_interest[2]
    if m[3] == max(m):
        return cluster_of_interest[3]

def parametric_clusters(row, c1, c2, c3):
	if row['monetary_value'] > 100000:
		return c1
	elif row['monetary_value'] > 30000:
		if row['average_days_between_orders'] > 6:
			return c2
		else:
			return c3
	else:
		return -1

# time_serie is a DataFrame
# Must contains following columns:
# 'InvoiceNo', 'StockCode', 
# 'Description', 'Quantity', 'InvoiceDate',
# 'UnitPrice', 'CustomerID', 'Country'
def predict(time_serie):
	#remove empty customer
	time_serie = time_serie[~time_serie['CustomerID'].isna()]
	time_serie = time_serie.reset_index()
	
	#import all pickles
	output = open('columns_to_keep.pkl', 'rb')
	columns_to_keep = pickle.load(output)
	
	output = open('encoder.pkl', 'rb')
	encoder = pickle.load(output)
	
	output = open('pca.pkl', 'rb')
	pca = pickle.load(output)
	
	output = open('scaler.pkl', 'rb')
	scaler = pickle.load(output)
	
	output = open('cluster_of_interest.pkl', 'rb')
	cluster_of_interest = pickle.load(output)
	
	output = open('huge_monetary_cluster.pkl', 'rb')
	huge_monetary_cluster = pickle.load(output)
	
	output = open('weekly_big_buyers_cluster.pkl', 'rb')
	weekly_big_buyers_cluster = pickle.load(output)
	
	output = open('dayly_big_buyers_cluster.pkl', 'rb')
	dayly_big_buyers_cluster = pickle.load(output)
	
	output = open('predictor.pkl', 'rb')
	clf = pickle.load(output)

	#add two columns
	time_serie['TotalPrice'] = time_serie['Quantity'] * \
								time_serie['UnitPrice']
	time_serie['TotalPrice2'] = time_serie['Quantity'] * \
								time_serie['UnitPrice']
	
	#one hot encoding
	df_encoded = encoder.transform(time_serie['Description'])
	df_encoded = pd.DataFrame(df_encoded.toarray())
	df_encoded.columns = np.asarray(encoder.get_feature_names())

	#remove useless words
	to_delete = list(set(list(df_encoded.columns)) - set(columns_to_keep))
	df_encoded = df_encoded.drop(columns=to_delete)
	
	#merge with initial dataframe
	df = pd.concat([time_serie, df_encoded], axis=1, join='inner')
	
	#DaysFromLastOrder
	NOW = datetime(2019,1,1)
	df_reduced = df.loc[:, ['CustomerID', 'InvoiceNo', 'InvoiceDate']] \
					.drop_duplicates() \
					.sort_values(['CustomerID', 'InvoiceDate'])
	
	#when no value for DaysFromLastOrder
	penality = 1000
	
	#calculate the number of days between two orders
	#by shifting the dataframes
	cond = df_reduced.CustomerID != df_reduced.CustomerID.shift(1)
	df_reduced['DaysFromLastOrder'] = (df_reduced.InvoiceDate - df_reduced.InvoiceDate.shift(1))
	df_reduced['DaysFromLastOrder'] = df_reduced['DaysFromLastOrder'].apply(lambda x: x.days)
	df_reduced.loc[cond, 'DaysFromLastOrder'] = penality
	
	#merge with main dataframe
	df = pd.merge(df, 
				  df_reduced.loc[:, ['CustomerID', 'InvoiceNo', 'DaysFromLastOrder']], 
				  on=['CustomerID', 'InvoiceNo'])
	
	#RFML Table
	rfmTable = df.groupby('CustomerID').agg({'InvoiceDate': lambda x: (NOW - x.max()).days, 
                                         'InvoiceNo': lambda x: len(x.drop_duplicates()),
                                         'TotalPrice': lambda x: x.sum(), 
                                         'TotalPrice2': lambda x: x.mean(), 
                                         'DaysFromLastOrder': lambda x: x[x > 0].mean()})
	rfmTable['InvoiceDate'] = rfmTable['InvoiceDate'].astype(int)
	rfmTable.rename(columns={'InvoiceDate': 'recency', 
                         'InvoiceNo': 'frequency', 
                         'TotalPrice': 'monetary_value',
                         'TotalPrice2': 'average_value',
                         'DaysFromLastOrder': 'average_days_between_orders'}, inplace=True)
	
	#Aggregate the sum of words occurences from One Hot Encoding
	df_ohe = pd.concat([df['CustomerID'], df.iloc[:, 11:-1]], axis=1, join='inner')
	df_ohe = df_ohe.groupby('CustomerID').agg(np.sum)
	
	#Merge with RFM table
	rfmTable = pd.merge(rfmTable, df_ohe, on='CustomerID')
	
	#remove null monetary value
	rfmTable = rfmTable[rfmTable['monetary_value'] != 0]
	rfmTable = rfmTable.reset_index()
	
	#PCA (only on One Hot Encoding)
	reduced_matrix = pca.transform(rfmTable.iloc[:,6:].values)
	df_reduced = pd.concat([rfmTable.iloc[:,0:6], 
							pd.DataFrame(reduced_matrix)], 
						   axis=1, 
						   join='inner')
	
	#Scale data (excluding CustomerID)
	df_reduced_norm = pd.DataFrame(scaler.transform(df_reduced.iloc[:, 1:]))
	df_reduced_norm.columns = df_reduced.columns[1:]
	
	#Predict
	X = df_reduced_norm.values
	y = pd.DataFrame(clf.predict(X))
	f = lambda row: select_max(row[:], cluster_of_interest)
	y = y.apply(f, axis=1)
	
	#Parametric case
	f = lambda row: parametric_clusters(row, 
										huge_monetary_cluster,
										weekly_big_buyers_cluster,
										dayly_big_buyers_cluster)
	y_param = df_reduced.apply(f, axis=1)
	
	for i in range(len(y_param)):
		if y_param[i] > -1:
			y[i] = y_param[i]
	
	return X, y