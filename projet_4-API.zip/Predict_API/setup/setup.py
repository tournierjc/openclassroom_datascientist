from predictor.models import Airport, Carrier, Distance
import pickle
import pandas as pd

pkl_file = open('setup/airports.pkl', 'rb')
airports = pickle.load(pkl_file)

for airport in airports.iterrows():
	tmp = Airport(name=airport[1]['ORIGIN'], code=airport[1]['ORIGIN'], city=airport[1]['ORIGIN_CITY_NAME'], db_id=airport[1]['ORIGIN_AIRPORT_ID'])
	tmp.save()
	
pkl_file = open('setup/carriers.pkl', 'rb')
carriers = pickle.load(pkl_file)

for carrier in carriers.iterrows():
	tmp = Carrier(name=carrier[1]['CARRIER'], db_id=carrier[1]['AIRLINE_ID'])
	tmp.save()

pkl_file = open('setup/distance.pkl', 'rb')
distances = pickle.load(pkl_file)

for distance in distances.iterrows():
	ap1 = Airport.objects.filter(db_id=distance[1]['ORIGIN_AIRPORT_ID']).first()
	ap2 = Airport.objects.filter(db_id=distance[1]['DEST_AIRPORT_ID']).first()
	tmp = Distance(airport_1=ap1, airport_2=ap2, distance=float(distance[1]['DISTANCE']))
	tmp.save()