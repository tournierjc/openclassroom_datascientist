from django import forms
from .models import Airport, Carrier
from django.contrib.admin import widgets

class PredictionForm(forms.Form):
	carrier = forms.ModelChoiceField(queryset=Carrier.objects.all().order_by('name'), empty_label=None, label="Carrier")
	departure_airport = forms.ModelChoiceField(queryset=Airport.objects.all().order_by('city'), empty_label=None, label="Departure")
	arriving_airport = forms.ModelChoiceField(queryset=Airport.objects.all().order_by('city'), empty_label=None, label="Arriving")
	departure_datetime = forms.DateTimeField(widget=forms.DateTimeInput(attrs={'class': 'datetime-input'}))