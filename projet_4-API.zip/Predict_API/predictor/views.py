from django.shortcuts import render
from .forms import PredictionForm
from sklearn import linear_model
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from .utils import ComputeDistance
import pickle, datetime
import numpy as np
import pandas as pd

def home(request):
	form = PredictionForm(request.POST or None)
	sent = False
	
	if request.method == "POST":
		if form.is_valid():
			#posted data
			departure_datetime = form.cleaned_data["departure_datetime"]
			carrier = form.cleaned_data["carrier"]
			origin = form.cleaned_data["departure_airport"]
			dest = form.cleaned_data["arriving_airport"]
			mean_1h_dep_delay = 10.0
			mean_2h_dep_delay = 10.0
			mean_3h_dep_delay = 10.0
			mean_1h_arr_delay = 10.0
			mean_2h_arr_delay = 10.0
			mean_3h_arr_delay = 10.0
			
			#carrier_encoder
			pkl_file = open('predictor/carrier_encoder.pkl', 'rb')
			carrier_encoder = pickle.load(pkl_file)
			
			#city_encoder
			pkl_file = open('predictor/airport_encoder.pkl', 'rb')
			airport_encoder = pickle.load(pkl_file)
			
			#dep_delay_estimator
			pkl_file = open('predictor/dep_delay_estimator.pkl', 'rb')
			dep_delay_estimator = pickle.load(pkl_file)
			
			#arr_delay_estimator
			pkl_file = open('predictor/arr_delay_estimator.pkl', 'rb')
			arr_delay_estimator = pickle.load(pkl_file)
			
			#retrieve distance
			pkl_file = open('predictor/scaler.pkl', 'rb')
			scaler = pickle.load(pkl_file)
			distance = scaler.fit_transform(np.array(ComputeDistance(origin, dest)).reshape(1,-1))
			
			#encode data
			carrierEncoded = carrier_encoder.transform([carrier.db_id])
			originEncoded = airport_encoder.transform([origin.db_id])
			destEncoded = airport_encoder.transform([dest.db_id])
			dt = departure_datetime.hour * 100 + departure_datetime.minute
			data = np.array([carrierEncoded, originEncoded, destEncoded, departure_datetime.weekday(), departure_datetime.month,  dt, mean_3h_dep_delay, mean_2h_dep_delay, mean_1h_dep_delay])
			data = data.reshape(1, -1)
			dep_delay = dep_delay_estimator.predict(data)
			
			data = np.array([carrierEncoded, originEncoded, destEncoded, departure_datetime.month,  dt, departure_datetime.weekday(), dep_delay, mean_3h_arr_delay, mean_2h_arr_delay, mean_1h_arr_delay, distance])
			data = data.reshape(1, -1)
			delay = arr_delay_estimator.predict(data)[0]
			
			sent = True
			

	return render(request, 'predictor/home.html', locals())
	