from django.apps import AppConfig


class PredictorConfig(AppConfig):
    name = 'predictor'
