from .models import Airport, Carrier, Distance
from datetime import date, time, timedelta

def ComputeDistance(airport_1, airport_2):
	#we look for a known distance in database
	distance = Distance.objects.filter(airport_1=airport_1, airport_2=airport_2).first()
	
	#if nothing we exchange airport_1 and _2
	if distance == None:
		distance = Distance.objects.filter(airport_1=airport_2, airport_2=airport_1).first()
		
		#else TODO : we look for a third point and choose the smallest distance
		if distance == None:
			return -1		
	
	return distance.distance