import django
from django.db import models
from django.conf import settings

class Airport(models.Model):
	name = models.CharField(max_length=100)
	city = models.CharField(max_length=100)
	code = models.CharField(max_length=4)
	db_id = models.IntegerField()
	
	def __str__(self):
		return self.city + " - " + self.code

class Carrier(models.Model):
	name = models.CharField(max_length=100)
	db_id = models.IntegerField()
	
	def __str__(self):
		return self.name

class Distance(models.Model):
	airport_1 = models.ForeignKey('Airport', on_delete=models.PROTECT, related_name='airport_1')
	airport_2 = models.ForeignKey('Airport', on_delete=models.PROTECT, related_name='airport_2')
	distance = models.DecimalField(max_digits=18, decimal_places=2)